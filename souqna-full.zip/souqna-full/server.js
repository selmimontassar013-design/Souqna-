"use strict";
// سوقنا: خادم بلا مكتبات خارجية (Node 18+). يقدّم التطبيق + واجهة API.
const http = require("http"), fs = require("fs"), path = require("path"), crypto = require("crypto");
const E = process.env, PORT = +E.PORT || 3000, ROOT = path.join(__dirname, "public");
const DBF = E.DATA_FILE || path.join(__dirname, "data", "db.json");
const BASE = (E.BASE_URL || "").replace(/\/+$/, "");
const KBASE = (E.KONNECT_API_BASE || "https://api.sandbox.konnect.network/api/v2").replace(/\/+$/, "");

const SEED = [
  { id: 1, n: "زيت زيتون بكر، لتر", v: "مزارع صفاقس", c: "غذاء", p: 28, e: "🫒", b: "#dfeccf" },
  { id: 2, n: "سلة حلفاء يدوية", v: "حرف القيروان", c: "حرف", p: 35, e: "🧺", b: "#f3e3c3" },
  { id: 3, n: "مزهرية فخار نابل", v: "فخار نابل", c: "حرف", p: 45, e: "🏺", b: "#f6d7c9" },
  { id: 4, n: "هريسة عربي، 380 غ", v: "مطبخ الوطن القبلي", c: "غذاء", p: 6.5, e: "🌶️", b: "#f7cfcb" },
  { id: 5, n: "تمر دقلة النور، كغ", v: "واحات توزر", c: "غذاء", p: 18, e: "🌴", b: "#efdcc0" },
  { id: 6, n: "عطر الياسمين", v: "عطور الحمامات", c: "عطور", p: 55, e: "🌼", b: "#f8efbd" },
  { id: 7, n: "حقيبة جلدية", v: "جلود المنستير", c: "أزياء", p: 120, e: "👜", b: "#e5d2c4" },
  { id: 8, n: "سماعات لاسلكية", v: "تك تونس", c: "إلكترونيات", p: 89, e: "🎧", b: "#d3e0f5" }
].map(x => Object.assign(x, { active: true }));

// ---------- التخزين (ملف JSON: مناسب للبداية فقط) ----------
let db;
function save() {
  fs.mkdirSync(path.dirname(DBF), { recursive: true });
  const t = DBF + ".tmp";
  fs.writeFileSync(t, JSON.stringify(db, null, 1));
  fs.renameSync(t, DBF);
}
try { db = JSON.parse(fs.readFileSync(DBF, "utf8")); }
catch (e) { db = { seq: 1000, products: SEED, orders: [], vendors: [] }; save(); }

// ---------- أدوات ----------
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json", ".webmanifest": "application/manifest+json", ".png": "image/png", ".svg": "image/svg+xml", ".txt": "text/plain; charset=utf-8" };
function send(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((ok, no) => {
    let s = "";
    req.on("data", c => { s += c; if (s.length > 100000) { no({ code: 413, error: "الطلب كبير جداً." }); req.destroy(); } });
    req.on("end", () => { try { ok(s ? JSON.parse(s) : {}); } catch (e) { no({ code: 400, error: "صيغة الطلب غير صحيحة." }); } });
    req.on("error", () => no({ code: 400, error: "خطأ في الطلب." }));
  });
}
const clean = (s, n) => String(s == null ? "" : s).replace(/[\u0000-\u001f<>]/g, " ").trim().slice(0, n);
const normPhone = p => String(p == null ? "" : p).replace(/[\s.\-]/g, "");
const PHONE = /^(\+?216)?\d{8}$/;
const hits = new Map();
function limited(ip) {
  const n = Date.now(), a = (hits.get(ip) || []).filter(t => n - t < 60000);
  a.push(n); hits.set(ip, a); return a.length > 20;
}
setInterval(() => hits.clear(), 600000).unref();
const ipOf = req => String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();
function adminCode(req) {
  const t = E.ADMIN_TOKEN; if (!t) return 503;
  const a = Buffer.from(String(req.headers["x-admin-token"] || "")), b = Buffer.from(t);
  return a.length === b.length && crypto.timingSafeEqual(a, b) ? 200 : 401;
}

// ---------- الدفع الإلكتروني: Konnect ----------
// الحقول مأخوذة من وثائق Konnect (المبلغ بالمليم). جرّبها في sandbox قبل الإنتاج.
const providers = {
  konnect: {
    async init(o) {
      if (!E.KONNECT_API_KEY || !E.KONNECT_WALLET_ID || !BASE) throw new Error("إعدادات Konnect ناقصة");
      const parts = o.customer.name.split(" "), first = parts[0], last = parts.slice(1).join(" ") || first;
      const r = await fetch(KBASE + "/payments/init-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": E.KONNECT_API_KEY },
        body: JSON.stringify({
          receiverWalletId: E.KONNECT_WALLET_ID, token: "TND", amount: Math.round(o.total * 1000),
          type: "immediate", description: "Souqna #" + o.no, acceptedPaymentMethods: ["wallet", "bank_card", "e-DINAR"],
          lifespan: 30, checkoutForm: false, addPaymentFeesToAmount: false,
          firstName: first, lastName: last, phoneNumber: o.customer.phone.slice(-8),
          email: o.customer.email || undefined, orderId: String(o.no),
          webhook: BASE + "/api/webhook/konnect", silentWebhook: true,
          successUrl: BASE + "/?paid=" + o.no, failUrl: BASE + "/?failed=" + o.no, theme: "light"
        })
      });
      const j = await r.json();
      if (!r.ok || !j.payUrl) throw new Error("Konnect: " + JSON.stringify(j).slice(0, 300));
      return { url: j.payUrl, ref: j.paymentRef };
    },
    async check(ref) {
      const r = await fetch(KBASE + "/payments/" + encodeURIComponent(ref), { headers: { "x-api-key": E.KONNECT_API_KEY } });
      const j = await r.json();
      return r.ok && j.payment && j.payment.status === "completed";
    }
  }
  // لإضافة بوابة أخرى (مثل Paymee): أضف كائناً بنفس الشكل { init(order), check(ref) } واسمه في PAYMENT_PROVIDER
};

// ---------- المسارات ----------
async function createOrder(req, res) {
  const b = await readBody(req), c = b.customer || {};
  const cu = { name: clean(c.name, 80), phone: normPhone(c.phone), address: clean(c.address, 200), email: clean(c.email, 100) };
  if (cu.name.length < 3) return send(res, 400, { error: "أدخل الاسم الكامل." });
  if (!PHONE.test(cu.phone)) return send(res, 400, { error: "رقم الهاتف غير صحيح (8 أرقام)." });
  if (cu.address.length < 8) return send(res, 400, { error: "أدخل عنوان التوصيل كاملاً." });
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 30) return send(res, 400, { error: "السلة فارغة." });
  const items = []; let total = 0;
  for (const it of b.items) {
    const p = db.products.find(x => x.id === it.id && x.active !== false), q = Math.floor(+it.qty);
    if (!p || !(q >= 1 && q <= 20)) return send(res, 400, { error: "منتج أو كمية غير صالحة." });
    items.push({ id: p.id, name: p.n, vendor: p.v, price: p.p, qty: q }); total += p.p * q;
  }
  total = Math.round(total * 1000) / 1000;      // السعر يُحسب هنا وليس من التطبيق
  const pay = b.payment === "online" ? "online" : "cod", prov = providers[E.PAYMENT_PROVIDER];
  if (pay === "online" && !prov) return send(res, 400, { error: "الدفع الإلكتروني غير مفعّل بعد. اختر الدفع عند الاستلام." });
  db.seq = (db.seq || 1000) + 1;
  const o = { no: db.seq, at: new Date().toISOString(), items, total, payment: pay, status: pay === "online" ? "pending_payment" : "new", customer: cu };
  if (pay === "online") {
    try { const r = await prov.init(o); o.ref = r.ref; db.orders.push(o); save(); return send(res, 201, { no: o.no, payment_url: r.url }); }
    catch (e) { console.error("payment init failed:", e.message); return send(res, 502, { error: "تعذّر بدء الدفع الإلكتروني. حاول لاحقاً أو اختر الدفع عند الاستلام." }); }
  }
  db.orders.push(o); save(); send(res, 201, { no: o.no });
}

async function createVendor(req, res) {
  const b = await readBody(req);
  const v = { shop: clean(b.shop, 80), name: clean(b.name, 80), phone: normPhone(b.phone), city: clean(b.city, 60), category: clean(b.category, 60) };
  if (v.shop.length < 3 || v.name.length < 3) return send(res, 400, { error: "أدخل اسم المتجر واسمك الكامل." });
  if (!PHONE.test(v.phone)) return send(res, 400, { error: "رقم الهاتف غير صحيح (8 أرقام)." });
  if (!db.vendors.some(x => x.phone === v.phone && x.shop === v.shop)) {
    db.seq = (db.seq || 1000) + 1;
    db.vendors.push(Object.assign({ id: db.seq, at: new Date().toISOString(), status: "pending" }, v)); save();
  }
  send(res, 201, { ok: true });
}

async function webhook(req, res, url) {
  res.writeHead(200); res.end("ok");
  const ref = clean(url.searchParams.get("payment_ref"), 64), prov = providers[E.PAYMENT_PROVIDER];
  const o = db.orders.find(x => x.ref && x.ref === ref);
  if (!o || !prov || o.status === "paid") return;
  try { if (await prov.check(ref)) { o.status = "paid"; o.paidAt = new Date().toISOString(); save(); } }
  catch (e) { console.error("webhook check failed:", e.message); }   // الحالة تُتحقق من الخادم نفسه، فلا يمكن تزويرها
}

async function adminRoutes(req, res, p, m) {
  const a = adminCode(req);
  if (a !== 200) return send(res, a, { error: a === 503 ? "لوحة الإدارة غير مفعّلة: اضبط ADMIN_TOKEN." : "غير مصرّح." });
  if (m === "GET" && p === "/api/admin/orders") return send(res, 200, db.orders.slice().reverse());
  if (m === "GET" && p === "/api/admin/vendors") return send(res, 200, db.vendors.slice().reverse());
  if (m === "POST") {
    const b = await readBody(req);
    if (p === "/api/admin/products") {
      const x = { n: clean(b.n, 100), v: clean(b.v, 80), c: clean(b.c, 40), p: +b.p, e: clean(b.e, 8) || "🛍️", b: /^#[0-9a-f]{6}$/i.test(b.b) ? b.b : "#e6edf7" };
      if (x.n.length < 2 || x.v.length < 2 || !x.c || !(x.p > 0 && x.p < 100000)) return send(res, 400, { error: "بيانات المنتج ناقصة." });
      x.id = db.products.reduce((mx, q) => Math.max(mx, q.id), 0) + 1; x.active = true; db.products.push(x); save(); return send(res, 201, x);
    }
    if (p === "/api/admin/order-status") {
      const o = db.orders.find(q => q.no === +b.no);
      if (!o || !["new", "confirmed", "shipped", "delivered", "cancelled", "paid"].includes(b.status)) return send(res, 400, { error: "طلب أو حالة غير صالحة." });
      o.status = b.status; save(); return send(res, 200, { ok: true });
    }
    if (p === "/api/admin/vendor-status") {
      const v = db.vendors.find(q => q.id === +b.id);
      if (!v || !["pending", "approved", "rejected"].includes(b.status)) return send(res, 400, { error: "بائع أو حالة غير صالحة." });
      v.status = b.status; save(); return send(res, 200, { ok: true });
    }
  }
  send(res, 404, { error: "غير موجود." });
}

function serve(req, res, pn) {
  let rel; try { rel = path.normalize(decodeURIComponent(pn)); } catch (e) { rel = ""; }
  let fp = path.join(ROOT, rel);
  if (!fp.startsWith(ROOT)) { res.writeHead(403); return res.end("forbidden"); }
  fs.stat(fp, (err, st) => {
    if (!err && st.isDirectory()) fp = path.join(fp, "index.html");
    fs.readFile(fp, (e, data) => {
      if (e) { res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); return res.end("غير موجود"); }
      res.writeHead(200, {
        "Content-Type": MIME[path.extname(fp)] || "application/octet-stream",
        "Cache-Control": /sw\.js$|index\.html$/.test(fp) ? "no-cache" : "public, max-age=3600",
        "X-Content-Type-Options": "nosniff", "Referrer-Policy": "same-origin"
      });
      res.end(req.method === "HEAD" ? undefined : data);
    });
  });
}

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://x"), p = url.pathname, m = req.method;
    if (p.startsWith("/api/")) {
      if (m === "POST" && limited(ipOf(req))) return send(res, 429, { error: "محاولات كثيرة، انتظر دقيقة ثم حاول." });
      if (m === "GET" && p === "/api/products") return send(res, 200, db.products.filter(x => x.active !== false).map(x => ({ id: x.id, n: x.n, v: x.v, c: x.c, p: x.p, e: x.e, b: x.b })));
      if (m === "POST" && p === "/api/orders") return await createOrder(req, res);
      if (m === "POST" && p === "/api/vendors") return await createVendor(req, res);
      if (p === "/api/webhook/konnect") return await webhook(req, res, url);
      if (p.startsWith("/api/admin/")) return await adminRoutes(req, res, p, m);
      return send(res, 404, { error: "غير موجود." });
    }
    if (m !== "GET" && m !== "HEAD") return send(res, 405, { error: "غير مسموح." });
    serve(req, res, p);
  } catch (e) {
    if (res.headersSent) return;
    if (e && e.code && e.error) return send(res, e.code, { error: e.error });
    console.error(e); send(res, 500, { error: "خطأ في الخادم." });
  }
}).listen(PORT, () => console.log("Souqna running on port " + PORT));
