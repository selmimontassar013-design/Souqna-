// روابط التطبيق. الثلاثة الأولى تشير إلى الخادم نفسه (server.js) وجاهزة للعمل.
// الدفع الإلكتروني يُضبط في الخادم عبر متغيرات البيئة (انظر README.txt)، وليس هنا.
window.SOUQNA_CONFIG = {
  APP_NAME: "سوقنا",
  PRODUCTS_URL: "/api/products",
  ORDERS_URL: "/api/orders",
  VENDOR_SIGNUP_URL: "/vendor.html",
  WHATSAPP: "",           // رقم واتساب بالصيغة الدولية، مثال 21620123456
  PHONE: "",              // رقم الهاتف للاتصال، مثال +21620123456
  TERMS_URL: "",          // صفحة الشروط والأحكام
  PRIVACY_URL: "",        // صفحة سياسة الخصوصية (إلزامية لـ Google Play)
  FACEBOOK_URL: "",
  INSTAGRAM_URL: ""
};
